# Facebook Scraper & Commenter: Quick Start Guide

This guide covers how to set up and run the Facebook Scraper. 

## 1. Clone the Repository & Install
First, download the code and install the necessary dependencies:

```bash
# Clone the repository
git clone https://github.com/best-amazing/Leads-Automation-Tool.git

# Navigate to the server folder
cd Leads-Automation-Tool/real-estate-scraper/server

# Install dependencies
npm install
```

## 2. Environment File (`.env`)
You don't need to manually configure the environment variables! 

Simply **copy the `.env` file** included in this ZIP folder and paste it directly into the `Leads-Automation-Tool/real-estate-scraper/server/` folder you just cloned. 

*(Make sure you place it inside the `server/` folder!)*

## 3. Stored Data (`facebook.json`)
When you run the scraper, all the property data it finds is saved into a JSON file for processing.
**Location:** `Leads-Automation-Tool/real-estate-scraper/server/logs/facebook.json`

If the scraper crashes during the commenting phase, it will safely resume using the data stored in this JSON file if you run the script with the `--skip-scrape` flag.

## 4. Commands to Run
Always run these commands from inside the `Leads-Automation-Tool/real-estate-scraper/server/` folder.

**Standard Run (Scrape & Comment):**
```bash
npm run scrape:facebook:with-comments
```

**Dry Run (Preview without posting):**
*Best for testing your setup and seeing what comments would be posted.*
```bash
npm run scrape:facebook:with-comments -- --dry-run
```

**Skip Scraping (Comment on already stored data):**
*Uses the data saved in `logs/facebook.json` instead of scraping Facebook again.*
```bash
npm run scrape:facebook:with-comments -- --skip-scrape
```

**Watch the Browser Automate (Non-Headless):**
```bash
npm run scrape:facebook:with-comments -- --headless false
```

**Filter by Price:**
```bash
npm run scrape:facebook:with-comments -- --min-price 50000 --max-price 500000
```
